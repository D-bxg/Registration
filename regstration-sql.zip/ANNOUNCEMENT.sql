INSERT INTO "ANNOUNCEMENT" VALUES ('1', 'a', 'a', 'a');
INSERT INTO "ANNOUNCEMENT" VALUES ('20', 'string', '近期公告', 'string');
