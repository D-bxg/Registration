INSERT INTO "NEWS" VALUES ('23', '数据结构', '10月9日-10月10日');
INSERT INTO "NEWS" VALUES ('5', '数学考试', '12月10日-12月12日');
INSERT INTO "NEWS" VALUES ('8', '英语四级', '10月2日');
